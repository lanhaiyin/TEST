#pragma once
#include "Environment.h"
namespace serviceTest {
	class CommUnitest{
	public:
		CommUnitest();
		int clear();
		//�����ı���Ϣ
		int sendText();
	private:
		std::shared_ptr<IChatService> m_chatService = nullptr;
	};
}

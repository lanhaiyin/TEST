#include "Environment.h"
namespace serviceTest{
	class DISABLED_Interface /*:public testing::Test*/{
	protected:
		virtual void TestBody() {}
	};
}
#include "unitest_comm.h"
CommUnitest::CommUnitest(){
	//��¼�˺�A
	int retA = g_test[0].loginByIndex(0);
	if (retA) {
		printf("A account Login failed,ret=%d", retA);
	}
	int retB = g_test[1].loginByIndex(1);
	if (retB) {
		printf("B account Login failed,ret=%d", retB);
	}
	m_chatService = g_test[0].CHATSERVICE();
}
int CommUnitest::sendText(){
	model::MsgText msgText;
	CommABInfo ABInfo;

	ABInfo = sdkUniTest::makeSemperUuid();
	msgText.targetId = m_config->getAccountInfo(1).m_iMyUserId; //B�˺�
	msgText.fromId = m_config->getAccountInfo(0).m_iMyUserId;   //A�˺�
	std::string text = std::string("this is a test message,test number:") + std::to_string(1);
	msgText.body = text;
	msgText.preDefined = Tools::getGUIDJson(ABInfo.uuid);

	std::promise<int> reqProm;
	std::future<int> reqFut = reqProm.get_future();
	m_chatService->sendMessage(msgText, [&](int code, int64 time, int64 msgid, BadWord& badword) {
		reqProm.set_value(code);
	});
	int code = reqFut.get();
	ABInfo.semer->wait();
	return code;
}
int CommUnitest::clear() {
	int retA = g_test[0].loginOutByIndex(0);
	if (retA) {
		printf("A account Logout failed,ret=%d", retA);
	}
	int retB = g_test[1].loginOutByIndex(1);
	if (retB) {
		printf("B account Logout failed,ret=%d", retB);
	}
	g_test[0].clearCllBack();
	g_test[1].clearCllBack();
	return 0;
}
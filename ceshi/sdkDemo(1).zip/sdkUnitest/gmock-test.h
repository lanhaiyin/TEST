#pragma once
#include "gmock/gmock.h"


class based {
public:
	virtual int display() = 0;
};





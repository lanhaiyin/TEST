﻿#include "tools.h"
#include "Environment.h"
#include "parson.h"
std::string Tools::GetModulePath()
{
	std::string strPath;
#ifdef _WIN32
	char path[260] = { 0 };
	_getcwd(path, sizeof(path));
	strPath = path;
	strPath += "\\";
#else
	strPath = getcwd(NULL, 0);
	strPath += "/";
#endif // 
	
	return strPath;
}
void Tools::sleep(int32 msec) {
#ifndef _WIN32
	usleep(msec * 1000);
#else
	Sleep(msec);
#endif
}
int64 Tools::strToInt64(const char * pNumber) {
	if (pNumber != NULL)
#ifdef WIN32
		return _atoi64(pNumber);
#else
		return strtoll(pNumber, NULL, 10);
#endif
	else
		return 0;
}
std::string Tools::int64_To_Str(int64 i) {
	char buffer[32] = "";
	sprintf(buffer, "%lld", i);
	return buffer;
}
std::shared_ptr<IMClient> Tools::getServiceClient() {
	std::shared_ptr<IMClient> result = nullptr;
#ifndef SDK_FOR_ANDROID 
	result = getClient();
#else
	std::string path = Tools::GetModulePath() + "libjniVimServicePresets.so";
	if (nullptr == g_handle) {
		g_handle = dlopen(path.c_str(), RTLD_NOW);
		if (nullptr == g_handle) {
			std::cout << "load failed,err msg=" << dlerror() << "dll Path=" << path.c_str() << std::endl;
			return result;
		}
	}
	SERVICE_FUC_PTR funcPtr = (SERVICE_FUC_PTR)dlsym(g_handle, "_ZN7service9getClientEv");
	if (nullptr == funcPtr) {
		std::cout << "load failed,err msg=" << dlerror() << " dll Path=" << path.c_str()<< std::endl;
		return result;
	}
	result = funcPtr();
#endif
	std::cout << "result=" << result.get() << std::endl;
	return result;
}
std::string Tools::int64ToStr(const int64 val){
	char buffer[32] = "";
	sprintf(buffer, "%lld", val);
	return buffer;
}
int64 Tools::getPID() {
#ifndef _WIN32
	int64 pid = getpid();
#else
	unsigned long pid = GetCurrentProcessId();
#endif
	return pid;
}
std::string Tools::getGUID() {
	char szBase[128] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	int  baseLen = strlen(szBase);
	char szBuffer[33] = "";
	for (int i = 0; i < 32; i++) {
		int tmp = rand();
		szBuffer[i] = szBase[tmp%baseLen];
	}
	std::string ret = szBuffer;
	return ret;
}
std::string Tools::getGUIDJson(const std::string&uuid){
	std::string result;
	JSON_Value * pJson = json_value_init_object();
	JSON_Object *root_object = json_value_get_object(pJson);

	json_object_set_string(root_object, "uuid", uuid.c_str());
	char *ptemp = json_serialize_to_string(pJson);
	if (nullptr != ptemp) {
		result = std::string(ptemp);
		json_free_serialized_string(ptemp);
	}
	return result;
}
std::string Tools::prasonGUIDJson(const std::string&json) {
	std::string result;
	JSON_Value * pJson = json_parse_string(json.c_str());
	if (pJson == nullptr) {
		result = "";
		return result;
	}
	JSON_Object *root_object = json_value_get_object(pJson);
	if (root_object == nullptr) {
		json_value_free(pJson);
		result = "";
		return result;
	}
	const char* uuidStr = json_object_get_string(root_object, "uuid");
	if (nullptr != uuidStr) {
		result = std::string(uuidStr).c_str();
	}
	json_value_free(pJson);
	return result;
}
int64 Tools::GetTime_t(int32 year, int32 month, int32 day) {
	struct tm date = { 0 };
	time_t	time = 0;

	if (year == 0 || month == 0 || day == 0) {
		return 0;
	}
	date.tm_year = year - 1900;
	date.tm_mon = month - 1;
	date.tm_mday = day;

	time = mktime(&date);

	return time;
}
int64 Tools::get_mill_sec() {
#ifndef  _WIN32
	struct timeval tv;
	gettimeofday(&tv, 0);
	int64 temp1 = tv.tv_sec;
	temp1 = temp1 * 1000;
	return temp1 + tv.tv_usec / 1000;
#else
	SYSTEMTIME systime;
	GetLocalTime(&systime);
	int64 dayTime = GetTime_t(systime.wYear, systime.wMonth, systime.wDay);

	int hour = systime.wHour;
	int minute = hour * 60 + systime.wMinute;
	int second = minute * 60 + systime.wSecond;
	int64 mills = second * 1000 + systime.wMilliseconds;

	return dayTime * 1000 + mills;
#endif
}
std::string Tools::GBToUTF8(const char* str) {
	std::string result;
#ifdef _WIN32
	WCHAR *strSrc;
	char *szRes;

	//获得临时变量的大小
	int i = MultiByteToWideChar(936, 0, str, -1, NULL, 0);
	strSrc = new WCHAR[i + 1];
	MultiByteToWideChar(936, 0, str, -1, strSrc, i);

	//获得临时变量的大小
	i = WideCharToMultiByte(CP_UTF8, 0, strSrc, -1, NULL, 0, NULL, NULL);
	szRes = new char[i + 1];
	int j = WideCharToMultiByte(CP_UTF8, 0, strSrc, -1, szRes, i, NULL, NULL);

	result = szRes;
	delete[]strSrc;
	delete[]szRes;
#else  //TODO
	result = str;
#endif
	return result;
}
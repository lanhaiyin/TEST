# The MIT License (MIT)
# Copyright © 2016 Naiyang Lin <maxint@foxmail.com>

#!/usr/bin/env bash
cmake -P $(dirname $0)/arcbuild.cmake $*

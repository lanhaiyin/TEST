#ifndef LDDPLUGIN_EXPORT_H
#define LDDPLUGIN_EXPORT_H

#include "interfaceExport.h"
#include "stdio.h"

/// 声明
EXPORT_PLUGIN CREATE_PLUGIN(lddplugin);
EXPORT_PLUGIN RELEASE_PLUGIN(lddplugin);

#endif

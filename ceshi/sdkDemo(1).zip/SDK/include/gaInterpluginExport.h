/*
 *  gaInterpluginExport.h
 *  内部,结构体定义
 *  Created on: 2018年4月17日
 *  Author: Liunux
 */

#ifndef INTERPLUGIN_EXPORT_H
#define INTERPLUGIN_EXPORT_H

#include "interfaceExport.h"
#include "stdio.h"

/// 声明
EXPORT_PLUGIN CREATE_PLUGIN(gaInterplugin);
EXPORT_PLUGIN RELEASE_PLUGIN(gaInterplugin);

#endif

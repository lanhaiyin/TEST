/*
 *  rtcpluginExport.h
 *  内部,结构体定义
 *  Created on: 2016年12月22日
 *  Author: corning
 */

#ifndef rtcPLUGIN_EXPORT_H
#define rtcPLUGIN_EXPORT_H

#include "interfaceExport.h"
#include "stdio.h"

/// 声明
EXPORT_PLUGIN CREATE_PLUGIN(rtcplugin);
EXPORT_PLUGIN RELEASE_PLUGIN(rtcplugin);

#endif

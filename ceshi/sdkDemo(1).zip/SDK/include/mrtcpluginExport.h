/*
 *  mrtcpluginExport.h
 */

#ifndef _MRTC_PLUGIN_EXPORT_H
#define _MRTC_PLUGIN_EXPORT_H

#include "interfaceExport.h"
#include "stdio.h"

/// 声明
EXPORT_PLUGIN CREATE_PLUGIN(mrtcplugin);
EXPORT_PLUGIN RELEASE_PLUGIN(mrtcplugin);

#endif // _MRTC_PLUGIN_EXPORT_H

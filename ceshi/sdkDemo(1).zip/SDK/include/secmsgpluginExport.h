#ifndef SEC_PLUGIN_EXPORT_H
#define SEC_PLUGIN_EXPORT_H

#include <interfaceExport.h>

/// ����
EXPORT_PLUGIN CREATE_PLUGIN(secmsgplugin);
EXPORT_PLUGIN RELEASE_PLUGIN(secmsgplugin);

#endif
